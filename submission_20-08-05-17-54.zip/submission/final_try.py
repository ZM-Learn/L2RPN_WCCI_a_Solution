# -*- coding: utf-8 -*-
"""
Created on Mon Jun 29 22:11:29 2020

@author: yanzm
"""

# final try
additional_action = 15
policy_chosen_list = np.argsort(policy_nn)[-1: -additional_action-1-1: -1]



            
            
            
            policy_chosen_list[additional_action-1] = 1007
            policy_chosen_list[additional_action-2] = 1006
            policy_chosen_list[additional_action-3] = 1002
            policy_chosen_list[additional_action-4] = 996
            policy_chosen_list[additional_action-5] = 933
            policy_chosen_list[additional_action-6] = 860
            policy_chosen_list[additional_action-7] = 799
            policy_chosen_list[additional_action-8] = 761
            policy_chosen_list[additional_action-9] = 738
            policy_chosen_list[additional_action-10] = 732
            policy_chosen_list[additional_action-11] = 727
            policy_chosen_list[additional_action-12] = 723
            policy_chosen_list[additional_action-13] = 694
            policy_chosen_list[additional_action-14] = 693
            policy_chosen_list[additional_action-15] = 649
            policy_chosen_list[additional_action-16] = 642
            policy_chosen_list[additional_action-17] = 636
            policy_chosen_list[additional_action-18] = 629
            policy_chosen_list[additional_action-19] = 586
            policy_chosen_list[additional_action-20] = 545
            policy_chosen_list[additional_action-21] = 534
            policy_chosen_list[additional_action-22] = 532
            policy_chosen_list[additional_action-23] = 514
            policy_chosen_list[additional_action-24] = 508
            policy_chosen_list[additional_action-25] = 499
            policy_chosen_list[additional_action-26] = 492
            policy_chosen_list[additional_action-27] = 490
            policy_chosen_list[additional_action-28] = 489
            policy_chosen_list[additional_action-29] = 484
            policy_chosen_list[additional_action-30] = 483
            policy_chosen_list[additional_action-31] = 478
            policy_chosen_list[additional_action-32] = 471
            policy_chosen_list[additional_action-33] = 466
            policy_chosen_list[additional_action-34] = 464
            policy_chosen_list[additional_action-35] = 461
            policy_chosen_list[additional_action-36] = 429
            policy_chosen_list[additional_action-37] = 427
            policy_chosen_list[additional_action-38] = 424
            policy_chosen_list[additional_action-39] = 423
            policy_chosen_list[additional_action-40] = 422
            policy_chosen_list[additional_action-41] = 421
            policy_chosen_list[additional_action-42] = 420
            policy_chosen_list[additional_action-43] = 417
            policy_chosen_list[additional_action-44] = 236
            policy_chosen_list[additional_action-45] = 192
            policy_chosen_list[additional_action-46] = 122
            
            policy_chosen_list[additional_action-46] = 77
            policy_chosen_list[additional_action-46] = 74
            policy_chosen_list[additional_action-46] = 73
            policy_chosen_list[additional_action-46] = 69
            policy_chosen_list[additional_action-46] = 55
            policy_chosen_list[additional_action-46] = 47
            policy_chosen_list[additional_action-46] = 44
            policy_chosen_list[additional_action-46] = 42
            
            policy_chosen_list[additional_action-46] = 22
            policy_chosen_list[additional_action-46] = 20
            policy_chosen_list[additional_action-46] = 19
            policy_chosen_list[additional_action-46] = 18
            
            policy_chosen_list[additional_action-46] = 14

            
            
            
            policy_chosen_list[additional_action-47] = 206
            policy_chosen_list[additional_action-48] = 754
            policy_chosen_list[additional_action-49] = 458
            policy_chosen_list[additional_action-50] = 456
            policy_chosen_list[additional_action-51] = 426